---
toc: true
toc-title: CONTENTS
title: Markdown+Pandoc Demonstration
author: shigaro
date: 2019-01-03
lang: en
CJKmainfont: Songti SC
mainfont: Times New Roman
colorlinks: true
linkcolor: red
filecolor: Cyan
urlcolor: Navy
toccolor: Ivory3
header-includes:
- \definecolors{Navy}
- \definecolors{Ivory3}
- \newcommand{\bGpp}{\mathbf{G}''}
---

# Introduction {#introduction}

Refer to [the header](#introduction) by add header identifier `{#introduction}` at the end of header.

Alternatively, use the implicit extension (case-insensitive): [Introduction].

# Definition

<a name="#inasmuch">inasmuch</a>

:   adv. 因……之故；由于……

    **inasmuch as**: used to explain the way in which what you are saying is true 鉴于，由于. 
    例如：
    
    > Ann is guilty, *inasmuch as* she knew what the others were planning. 
    > 
    > 鉴于安对其他人的计划知情，所以她是有罪的。

# Links

*N. B.*: please adopt the absolute path locally.

Internal link by a HTML anchor works with HTML convertion, but not with LaTeX: [inasmuch](#inasmuch). 

External link with relative path ([HW.md](HW.md)) seems to behave the same to file link with `run:` and relative path ([HW.md](run:./HW.md)) on macOS, converted from LaTeX.

External link with `file://` and relative path: [HW.md](file://./HW.md)

External link absolute path: [HW.md](/Users/stevezhang/Documents/SelfDevelopment/Notes/Markdown/HW.md)

File link with `run:` and absolute path: [HW.md](run:/Users/stevezhang/Documents/SelfDevelopment/Notes/Markdown/HW.md)

URL link: [Google](https://www.google.com)

# Code

## Python {-}

```python
def hello_world():
    print("Hello World!")
```

## Fortran {-}

```fortran
PROGRAM HELLO_WORLD
    write(*,*) "Hello World!"
END PROGRAM HELLO_WORLD
```

# Math

Inline math: `$a=b+c$` gives $a=b+c$.

Display math: 
```latex
$$\int^{\infty}_{-\infty}{{\rm d}x\,e^{-x^2}}=\sqrt{\pi}$$
```

$$\int^{\infty}_{-\infty}{{\rm d}x\,e^{-x^2}}=\sqrt{\pi}$$

Use the latex environment `\begin{equation}` for numbered math
```latex
\begin{equation}\label{eq:eular}
e^{i\pi} = 1
\end{equation}
```

Result:

\begin{equation}\label{eq:eular}
e^{i\pi} = 1
\end{equation}

and it is referred as \eqref{eq:eular}.

Custom commands can be set by adding to `header-include` pandoc variable.
For example, adding

```latex
\newcommand{\bGpp}{\mathbf{G}''}
```
and we now have `$\bGpp$`=$\bGpp$. Great!

# 注解

## 一般脚注

可以插入一个一般的脚注[^footnote1]，这个脚注里不包含任何的参考文献。

## 参考文献

这是一篇参考文献`[@DeGiovannini2017]`. [@DeGiovannini2017] 

## 脚注中插参考文献

这是一个有参考文献的脚注.[^footnote2]

[^footnote1]: 这是一个非引用文献的脚注
[^footnote2]: 这个脚注包含引用.`[@Giustino2017]`. [@Giustino2017]



# Figures

This figure will have a caption of “This is my website logo”

![This is my website logo](icon.jpg)