Use `callgrind` as profiling backend:

```bash
$ make callgrind
$ make cg2dot
```

or use `gprof` as profiling backend

```bash
$ make gprof
$ make gp2dot
```

and use 

```bash
$ make dot
```

to generate PNG output
