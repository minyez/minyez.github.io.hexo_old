#!/usr/bin/env python3

import numpy as np
from random import seed, random

def np_matmul(m1, m2):
    return np.matmul(m1, m2)


def scipy_dgemm(m1, m2):
    from scipy import linalg
    return linalg.blas.dgemm(1.0, m1, m2)


def fortran_matmul(m1, m2):
    from f_matmul import f_matmul
    return f_matmul(m1, m2)


def mkl_dgemm(m1, m2):
    from f_dgemm import f_dgemm
    return f_dgemm(m1, m2)


def main():
    # set the dimensions
    m = 100
    k = 100
    n = 100
    
    # create mat1(m,k) and mat2(k,n) matrices
    seed()
    mat1 = np.array([[random() for col in range(k)] for row in range(m)], \
                    order='F', dtype='float64')
    seed()
    mat2 = np.array([[random() for col in range(n)] for row in range(k)], \
                    order='F', dtype='float64')
    
    # numpy matmul
    #mat3 = np_matmul(mat1, mat2)
    
    # scipy
    #mat3 = scipy_dgemm(mat1, mat2)
    
    # fortran matmul
    #mat3 = fortran_matmul(mat1, mat2)
    
    # MKL DGEMM
    mat3 = mkl_dgemm(mat1, mat2)

if __name__ == "__main__":
    main()
